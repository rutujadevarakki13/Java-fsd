public class ExponentialSearch {

    public static int exponentialSearch(int[] array, int target) {
        if (array[0] == target) {
            return 0; // Return 0 if the target element is found at the first index
        }

        int size = array.length;
        int bound = 1;

        while (bound < size && array[bound] <= target) {
            bound *= 2;
        }

        int left = bound / 2;
        int right = Math.min(bound, size - 1);

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (array[mid] == target) {
                return mid; // Return the index where the target element is found
            }

            if (array[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; // Return -1 if the target element is not found
    }

    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 5, 7, 9};
        int target = 7;

        int index = exponentialSearch(numbers, target);
        if (index != -1) {
            System.out.println("Target element found at index: " + index);
        } else {
            System.out.println("Target element not found in the array.");
        }
    }
}
