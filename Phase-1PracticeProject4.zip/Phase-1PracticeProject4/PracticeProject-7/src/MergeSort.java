public class MergeSort {

    public static void mergeSort(int[] array) {
        if (array.length <= 1) {
            return; // Base case: array is already sorted or empty
        }

        int mid = array.length / 2;
        int[] leftArray = new int[mid];
        int[] rightArray = new int[array.length - mid];

        // Fill the left and right subarrays
        for (int i = 0; i < mid; i++) {
            leftArray[i] = array[i];
        }
        for (int i = mid; i < array.length; i++) {
            rightArray[i - mid] = array[i];
        }

        mergeSort(leftArray); // Recursively sort the left subarray
        mergeSort(rightArray); // Recursively sort the right subarray

        merge(leftArray, rightArray, array); // Merge the sorted subarrays
    }

    private static void merge(int[] leftArray, int[] rightArray, int[] resultArray) {
        int i = 0; // Index for left subarray
        int j = 0; // Index for right subarray
        int k = 0; // Index for merged array

        while (i < leftArray.length && j < rightArray.length) {
            if (leftArray[i] <= rightArray[j]) {
                resultArray[k++] = leftArray[i++];
            } else {
                resultArray[k++] = rightArray[j++];
            }
        }

        // Copy remaining elements from the left subarray
        while (i < leftArray.length) {
            resultArray[k++] = leftArray[i++];
        }

        // Copy remaining elements from the right subarray
        while (j < rightArray.length) {
            resultArray[k++] = rightArray[j++];
        }
    }

    public static void main(String[] args) {
        int[] numbers = {5, 2, 7, 1, 9, 3};

        System.out.println("Before sorting:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }

        mergeSort(numbers);

        System.out.println("\nAfter sorting:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
    }
}
