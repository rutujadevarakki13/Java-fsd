public class LinkedList {
    private Node head;
    
    public LinkedList() {
        head = null;
    }
    
    private static class Node {
        private int data;
        private Node next;
        
        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
    
    public void insertFront(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }
    
    public void deleteKey(int key) {
        Node prev = null;
        Node current = head;
        
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }
        
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }
        
        if (current == null) {
            return;
        }
        
        prev.next = current.next;
    }
    
    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.insertFront(5);
        list.insertFront(3);
        list.insertFront(9);
        list.insertFront(1);
        list.insertFront(7);
        System.out.print("Original list: ");
        list.printList();
        int key = 9;
        list.deleteKey(key);
        System.out.print("List after deleting " + key + ": ");
        list.printList();
    }
}
