public class CircularLinkedList {
    private Node head;
    
    private static class Node {
        private int data;
        private Node next;
        
        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
    
    public CircularLinkedList() {
        head = null;
    }
    
    public void insertSorted(int data) {
        Node newNode = new Node(data);
        
        if (head == null) {
            newNode.next = newNode;
            head = newNode;
            return;
        }
        
        Node current = head;
        
        if (current.data >= newNode.data) {
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
            return;
        }
        
        while (current.next != head && current.next.data < newNode.data) {
            current = current.next;
        }
        
        newNode.next = current.next;
        current.next = newNode;
    }
    
    public void printList() {
        if (head == null) {
            System.out.println("Empty list");
            return;
        }
        
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
    
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();
        list.insertSorted(5);
        list.insertSorted(3);
        list.insertSorted(9);
        list.insertSorted(1);
        list.insertSorted(7);
        System.out.print("Circular list: ");
        list.printList();
    }
}
