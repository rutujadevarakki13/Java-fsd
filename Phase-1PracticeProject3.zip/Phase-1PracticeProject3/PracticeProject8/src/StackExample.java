import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Inserting elements into the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        System.out.println("Stack: " + stack);

        // Removing elements from the stack
        int element = stack.pop();
        System.out.println("Popped element: " + element);
        System.out.println("Stack after popping: " + stack);

    }
}
