import java.util.*;
public class QueueExample 
{
public static void main(String[] args) 
{
        		Queue<String> carsQueue = new LinkedList<>();
carsQueue.add("Mercedes");
        		carsQueue.add("Ford");
        		carsQueue.add("Kia");
        		carsQueue.add("Audi");
        		carsQueue.add("Chevy");
System.out.println("Queue is : " + carsQueue);
        		System.out.println("Head of Queue : " + carsQueue.peek());
        		carsQueue.remove();
        		System.out.println("After removing Head of Queue : " + carsQueue);
        		System.out.println("Size of Queue : " + carsQueue.size());
    	}
}
