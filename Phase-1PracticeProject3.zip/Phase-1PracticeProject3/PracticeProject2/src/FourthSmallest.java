class nthSmallst 
{ 
int nthSmallest(int arr[], int l, int r, int n) 
    	{ 
             		if (n > 0 && n <= r - l + 1) 
        		{ 
            			int pos = randomPartition(arr, l, r); 
            			if (pos-l == n-1) 
                			return arr[pos]; 
            			if (pos-l > n-1) 
                			return nthSmallest(arr, l, pos-1, n); 
            			return nthSmallest(arr, pos+1, r, n-pos+l-1); 
        		} 
        return Integer.MAX_VALUE; 
    } 
    void swap(int arr[], int i, int j) 
    { 
        int temp = arr[i]; 
        arr[i] = arr[j]; 
        arr[j] = temp; 
    } 
    int partition(int arr[], int l, int r) 
    { 
        int x = arr[r], i = l; 
        for (int j = l; j <= r - 1; j++) 
        { 
            if (arr[j] <= x) 
            { 
                swap(arr, i, j); 
                i++; 
            } 
        } 
        swap(arr, i, r); 
        return i; 
    } 
    int randomPartition(int arr[], int l, int r) 
    { 
        int n = r-l+1; 
        int pivot = (int)(Math.random()) * (n-1); 
        swap(arr, l + pivot, r); 
        return partition(arr, l, r); 
    } 
}  
public class FourthSmallest
{
	public static void main(String[] args) {
		nthSmallst ob = new nthSmallst(); 
        int arr[] = {12, 3, 5, 7, 4, 19, 26}; 
        int n = arr.length,k = 4; 
        System.out.println("Fourth smallest element is "+ ob.nthSmallest(arr, 0, n-1, k)); 
    }
}
