// Define a subclass of "Animal" called "Dog"
class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }

    @Override
    public void makeSound() {
        System.out.println(getName() + " says woof!");
    }
}