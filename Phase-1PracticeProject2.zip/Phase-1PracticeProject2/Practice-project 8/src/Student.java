
// Define a subclass of "Person" called "Student"
class Student extends Person {
    private String major;

    public Student(String name, int age, String major) {
        super(name, age);
        this.major = major;
    }

    public String getMajor() {
        return this.major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void printInfo() {
        super.printInfo();
        System.out.println("Major: " + this.major);
    }
}
