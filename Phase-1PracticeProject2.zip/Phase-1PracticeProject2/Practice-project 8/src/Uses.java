

// Define a class called "Person"
class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return this.age;
    }

    public void printInfo() {
        System.out.println("Name: " + this.name);
        System.out.println("Age: " + this.age);
    }
}

// Define a class called "Main"
public class Uses {
    public static void main(String[] args) {
        // Demonstrate abstraction with "Animal" class and subclasses
        Animal dog = new Dog("Rufus");
        Animal cat = new Cat("Whiskers");

        dog.makeSound(); // Output: Rufus says woof!
        cat.makeSound(); // Output: Whiskers says meow!

        // Demonstrate encapsulation with "Person" class and subclasses
        Person person1 = new Person("Alice", 25);
        Student student1 = new Student("Bob", 20, "Computer Science");

        person1.printInfo(); // Output: Name: Alice, Age: 25
        student1.printInfo(); // Output: Name: Bob, Age: 20, Major: Computer Science

        student1.setMajor("Mathematics");
        student1.printInfo(); // Output: Name: Bob, Age: 20, Major: Mathematics

        // Demonstrate inheritance with "Person" and "Student" classes
        Person person2 = new Student("Charlie", 22, "Engineering");
        person2.printInfo(); // Output: Name: Charlie, Age: 22, Major: Engineering

        // Demonstrate polymorphism with "Animal" and "Dog" classes
        Animal animal = new Dog("Buddy");
        animal.makeSound(); // Output: Buddy says woof!
    }
}
