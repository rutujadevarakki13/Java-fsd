
// Define a subclass of "Animal" called "Cat"
class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }

    @Override
    public void makeSound() {
        System.out.println(getName() + " says meow!");
    }
}