public class SleepAndWaitEx {
    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new Thread(new Runnable() {
            public void run() {
                try {
                    System.out.println("Thread t1 is sleeping for 5 seconds.");
                    Thread.sleep(5000);
                    System.out.println("Thread t1 has woken up.");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        Thread t2 = new Thread(new Runnable() {
            public void run() {
                synchronized (this) {
                    try {
                        System.out.println("Thread t2 is waiting.");
                        wait();
                        System.out.println("Thread t2 has been notified.");
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        t1.start();
        t2.start();

        // Let's wait for both threads to finish before exiting.
        t1.join();
        t2.join();
    }
}
