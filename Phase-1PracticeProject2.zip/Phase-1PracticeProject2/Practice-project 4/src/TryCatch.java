import java.util.Scanner;

public class TryCatch {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        try {
            int num = scanner.nextInt();
            int result = 100 / num;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Please enter a non-zero number.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Please enter a valid number.");
        }

        System.out.println("Program finished.");
    }
}


