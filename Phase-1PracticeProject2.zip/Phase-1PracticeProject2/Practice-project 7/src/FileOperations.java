import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileOperations{
    public static void main(String[] args) {
        // Create a new file
        File file = new File("file.txt");

        try {
            boolean result = file.createNewFile();
            if (result) {
                System.out.println("File created successfully.");
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }

        // Write to the file
        String content = "This is the content that will be written to the file.";
        try {
            Files.write(Paths.get("file.txt"), content.getBytes());
            System.out.println("Content written to file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }

        // Read from the file
        try {
            String readContent = Files.readString(Paths.get("file.txt"));
            System.out.println("The content of the file is: " + readContent);
        } catch (IOException e) {
            System.out.println("An error occurred while reading from the file: " + e.getMessage());
        }

        // Update the file
        String updatedContent = "This is the updated content that will be written to the file.";
        try {
            Files.write(Paths.get("file.txt"), updatedContent.getBytes());
            System.out.println("Content updated in file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file: " + e.getMessage());
        }

        // Delete the file
        try {
            Path path = Paths.get("file.txt");
            boolean result = Files.deleteIfExists(path);
            if (result) {
                System.out.println("File deleted successfully.");
            } else {
                System.out.println("File not found or could not be deleted.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while deleting the file: " + e.getMessage());
        }
    }
}
