import java.util.Scanner;

class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

public class ExceptionEx {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter your age: ");
            int age = scanner.nextInt();

            if (age < 0 || age > 120) {
                throw new InvalidAgeException("Invalid age entered!");
            }

            System.out.println("Age entered: " + age);
        } catch (InvalidAgeException e) {
            System.out.println("Invalid age entered: " + e.getMessage());
        } finally {
            System.out.println("Thank you for using the program!");
            scanner.close();
        }
    }
}

