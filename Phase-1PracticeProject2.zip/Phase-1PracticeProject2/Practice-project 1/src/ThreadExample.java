public class ThreadExample {
    public static void main(String[] args) {
        // Create a thread by extending the 'Thread' class
        MyThread myThread = new MyThread();
        myThread.start();
        
        // Create a thread by implementing the 'Runnable' interface
        MyRunnable myRunnable = new MyRunnable();
        Thread thread = new Thread(myRunnable);
        thread.start();
    }
}