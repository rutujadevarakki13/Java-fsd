// Create a thread by implementing the 'Runnable' interface
class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread created by implementing Runnable interface.");
    }
}