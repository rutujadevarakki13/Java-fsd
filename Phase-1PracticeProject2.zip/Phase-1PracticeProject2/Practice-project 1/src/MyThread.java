// Create a thread by extending the 'Thread' class
class MyThread extends Thread {
    public void run() {
        System.out.println("Thread created by extending Thread class.");
    }
}