public class Constructor {
    private String make;
    private String model;
    private int year;

    // Default constructor
    public Constructor() {
        make = "Unknown";
        model = "Unknown";
        year = 0;
    }

    // No-args constructor
    public Constructor(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    // Parameterized constructor
    public Constructor(String make, String model) {
        this.make = make;
        this.model = model;
        year = 0;
    }

    public void display() {
        System.out.println("Make: " + make);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
    }

    public static void main(String[] args) {
        // Create a car using the default constructor
    	Constructor car1 = new Constructor();
        car1.display();

        // Create a car using the no-args constructor
        Constructor car2 = new Constructor("Toyota", "Corolla", 2019);
        car2.display();

        // Create a car using the parameterized constructor
        Constructor car3 = new Constructor("Ford", "Mustang");
        car3.display();
    }
}