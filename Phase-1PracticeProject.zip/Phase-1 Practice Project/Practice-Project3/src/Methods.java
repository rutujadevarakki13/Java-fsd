public class Methods {
	//calling the addition method
	public int addition(int a, int b) {
		int c = a+b;
		return c;
	}
	
	//call by value
	public void increment(int x) {
		x = x + 1;
		System.out.println("while increment: "+ x);
	}
	
	public void area(int l,int b,int r ) {
		float rect = l*b;
		System.out.println("Area of rectangle: " + rect );
		double circle = 3.14*r*r;
		System.out.println("Area of circls: " + circle );
	}
	
	
	public static void main(String[] args) {
		Methods method = new Methods();
		System.out.println("Addition of two numbers:  " +method.addition(120, 250));
		int x = 10;
		System.out.println("Before increment: "+ x);
		method.increment(x);
		System.out.println("After increment: "+ x);
		method.area(12, 5, 5);
		
	}
}