
public class typeCasting {

	public static void main(String[] args) {
		
		//implicit conversion
		System.out.println("Implicit Type Casting");
		char a='A';
		System.out.println("Value of a: "+a);
		
		int b=a;
		System.out.println("Value of b: "+b);
		
		int p = 7;
		
		long q = p;
		
		float r = q;
		
		System.out.println("Before conversion,int value"+p);
		
		System.out.println("After conversion,long value"+q);
		
		System.out.println("After conversion,float value"+r);
				
		System.out.println("\n");
		
		System.out.println("Explicit Type Casting");
		//explicit conversion
		
		double x=9.99;
		int y=(int)x;
		System.out.println("Value of x: "+x);
		System.out.println("Value of y: "+y);
		
	}
}

