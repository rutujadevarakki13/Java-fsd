package pack1;

public class AccessModifiers {
    public int publicVariable = 10;
    private int privateVariable = 20;
    protected int protectedVariable = 30;

    public void publicMethod() {
        System.out.println("This is a public method.");
    }

    private void privateMethod() {
        System.out.println("This is a private method.");
    }

    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }


    protected void defaultMethod() {
        System.out.println("This is a default method.");
    }
    

    public static void main(String[] args) {
        AccessModifiers exp = new AccessModifiers();
        
        System.out.println("Public variable: " + exp.publicVariable);
        exp.publicMethod();
        
        System.out.println("Protected variable: " + exp.protectedVariable);
        exp.protectedMethod();
        
        System.out.println("Private variable: " + exp.privateVariable);
        exp.privateMethod();

        exp.defaultMethod();
    }
}