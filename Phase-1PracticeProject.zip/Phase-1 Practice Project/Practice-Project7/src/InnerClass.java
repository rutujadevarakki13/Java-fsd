public class InnerClass {
private String msg = "Hello World!!";
public class Inner {
    public void hello() {
        System.out.println(msg + ", Good Morning");
    }

    public void msg() {
        System.out.println(msg);
    }
}

public void display() {
    System.out.println("Anonymous Inner Class");
}

public static void main(String[] args) {
    InnerClass obj = new InnerClass();
    InnerClass.Inner in = obj.new Inner();
    in.hello();
    obj.display();
}
}